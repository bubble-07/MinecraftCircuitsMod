//package minecraftbyexample.testingarea.fluid;
//
//import net.minecraft.block.material.MapColor;
//import net.minecraft.block.material.MaterialLiquid;
//
//public class MaterialGemLiquid extends MaterialLiquid
//{
//	public MaterialGemLiquid(MapColor color)
//	{
//		super(color);
//	}
//
//	@Override
//	public boolean getCanBurn()
//	{
//		return true;
//	}
//}